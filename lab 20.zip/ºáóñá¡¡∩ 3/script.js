function mul(...params) {
  let result = 1;
  for (let param of params) {
    if (typeof param === "number") {
      result *= param;
    }
  }
  return result;
}

console.log(mul(1, "str", 2, 3, true)); // 6
console.log(mul(null, "str", false, true)); // 0
